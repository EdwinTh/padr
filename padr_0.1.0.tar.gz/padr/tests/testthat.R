library(testthat)
library(padr)

test_check("padr")
